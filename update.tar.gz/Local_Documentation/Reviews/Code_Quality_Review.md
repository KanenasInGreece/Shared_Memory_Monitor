# Code Quality Review: shared-memory-monitor v0.9.12..HEAD

**Target:** `v0.9.12..HEAD` (v0.9.13)
**Project:** `shared-memory-monitor`
**Role:** Code Quality Reviewer

## 1. Correctness (I12–I17, A5–A9)
* **I12 & I13 (Passthrough & Join):** The implementations in `src/sm_telemetry_monitor/system_health.py` correctly implement flat passthroughs for `llm_routing` and `llm_token_usage` without inventing empty objects or zero values. The `_join_token_usage_onto_backends` safely maps usage keys onto the pool’s backend URLs, correctly handling stripping of trailing slashes.
* **I16 (Descriptors Copy):** The `_copy_backend_descriptors` helper isolates the key transfers gracefully, accurately preserving explicit `null` from the gateway. 
* **I17 (`allow_unauthenticated_provider_keys`):** Properly cascades from `config` fallback to `raw` root.
* **A5–A9 (UI Display Logic):** `static/dashboard.html` correctly translates the payloads into HTML, appropriately gating visual warnings (`unauthWarn`, `poolLineWarn`) on non-null values and preventing UI invention of missing descriptors.

## 2. Readability & Architecture
* **Modularity:** The separation of `_copy_backend_descriptors` and `_join_token_usage_onto_backends` prevents inline bloat in the main `_llm_pool_summary` builder, keeping the extraction logic clean and composable.
* **Resilience:** The telemetry monitor operates defensively, only rendering metadata if it is explicitly provided by the gateway, which ensures forward/backward compatibility.

## 3. Surface Security
* **XSS Prevention:** In `static/dashboard.html`, the dynamic HTML injection for pool descriptor bits uses `esc(t)` correctly when constructing `pool-pop-meta-row`, preventing DOM-based XSS if backend strings contain unsanitized input. 
* *Deep threat model deferred to Security (fact:1366).*

## 4. Performance
* **Loop Efficiency:** The backend array merges in `_join_token_usage_onto_backends` build a temporary normalisation dictionary (`by_norm`), resulting in a single $O(N)$ pass for usage keys and another $O(M)$ pass for backends, avoiding nested loops. Safe and bounded.

## 5. Minor Nits
* **JS Type Coercion in Price Check:** The `hasPrice` check in `poolTokenBits` (`v != null && v !== "" && Number.isFinite(Number(v))`) would evaluate to `true` if `v` is a boolean `false` or an empty array `[]` (since `Number(false) === 0`). This is practically harmless since the gateway serializes prices as floats or omits them, but it is an imperfect numeric validation.

## FINDINGS SUMMARY

| id | severity | one-line claim | evidence pointer |
|---|---|---|---|
| CQ-01 | Nit | Loose JS type coercion for numeric prices may treat boolean `false` as `0.0`. | `static/dashboard.html` `hasPrice` in `poolTokenBits` |
