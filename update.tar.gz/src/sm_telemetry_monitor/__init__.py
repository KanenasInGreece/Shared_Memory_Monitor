"""Read-only view over gateway telemetry and framework logs — no separate data interfaces."""

__version__ = "0.9.16"