# Agent ops cheat sheet — Shared Memory Monitor

## One-liner health

```bash
cd /home/xenofon/grok-labs/projects/shared-memory-monitor && \
  ./scripts/agent-status.sh && \
  ./scripts/check-env.sh && \
  systemctl --user is-active hive-mind-gateway.service shared-memory-monitor.service && \
  curl -sf http://127.0.0.1:8765/api/health | python3 -c "
import sys,json;d=json.load(sys.stdin)
print((d.get('config') or {}).get('summary'))
print([(b.get('label'), b.get('placement')) for b in ((d.get('llm_pool') or {}).get('backends') or [])])
"
```

Doctor connectivity should name modern panels and placement when the gateway supports them:

```text
coordinator: ok · gateway 0.8.9 · api server=3 client=3 compat=ok · 2 LLM backends · llm_pool · placement local
telemetry: ok · nrem+breakdown+consolidation+entity_graph+latency+spine+compliance
```

## systemd

| Unit | Role |
|------|------|
| `hive-mind-gateway.service` | Framework gateway :8888 |
| `shared-memory-monitor.service` | Poll loop + dashboard :8765 |

Install monitor unit: `./scripts/install-systemd-user.sh`  
User linger required: `loginctl show-user $USER -p Linger` → `yes`

## CLI entry points

```bash
uv run python -m sm_telemetry_monitor check
uv run python -m sm_telemetry_monitor --once
uv run python -m sm_telemetry_monitor loop --serve --interval 600
```

## Publish

```bash
./scripts/pre-publish-check.sh   # must pass
git status                       # no .env staged
./scripts/publish.sh
```

## Troubleshooting quick map

| Symptom | Action |
|---------|--------|
| `skill:grok` token source | Put dedicated monitor token in project `.env` |
| `nrem_backlog_source: estimate` | Upgrade/restart framework coordinator (`telemetry.nrem`) |
| Empty breakdown | Gateway needs `telemetry.breakdown` |
| No local/external LLM badges | Need gateway ≥0.8.9 `config.llm_backends[].has_credential`; multi-backend for pool panel |
| Doctor missing `entity_graph` / `latency` | Optional panels — upgrade framework |
| 401 on poll | Token missing from gateway `AGENT_TOKENS` |
| Port 8765 busy | Stop foreground server or `systemctl --user stop shared-memory-monitor.service` |
| Empty gateway logs tab | `journalctl --user -u hive-mind-gateway.service -n 5` |
| Backup **Last never** / `backup: null` on `/api/health` | Restart `shared-memory-monitor.service`; set `BACKUP_DIR` in monitor `.env` if manifests are outside default path |
| `last_at` missing but manifests exist | Confirm `BACKUP_DIR` readable by monitor user; check `sm-backup-*.manifest.json` has `created` |

## Test

```bash
uv run pytest -q
```