---
name: shared-memory-monitor
description: Maintainer and operator skill for the Shared Memory Monitor sister repo — live REM/NREM dashboard on :8765, thin httpx client to Hive-Mind Gateway :8888. Use when the user opens this project, runs /shared-memory-monitor, mentions shared-memory-monitor, sm_telemetry_monitor, telemetry monitor, monitor dashboard, publish monitor, or wants fixes/features/docs/systemd for the ops UI. On a fresh conversation in this project, run check-env and summarize service status before coding. Never commit .env or tokens.
---

# Shared Memory Monitor (agent maintainer)

Sister repo to [Shared Memory Framework](https://github.com/KanenasInGreece/Shared_Memory). This project is **not** part of the framework — a read-only **view** over **gateway telemetry** (`bridge.py`) and **framework logs** (`logs_reader.py`). No separate monitor metrics API; no `psycopg`; no `memory_bridge.py` imports. `data/telemetry.db` caches past `GET /memory/telemetry` polls; `:8765` `/api/*` is UI transport only.

## Project identity

| Item | Value |
|------|-------|
| Local root | `/home/xenofon/grok-labs/projects/shared-memory-monitor` |
| GitHub | https://github.com/KanenasInGreece/Shared_Memory_Monitor |
| Remote | `git@github.com:KanenasInGreece/Shared_Memory_Monitor.git` |
| Branch | `main` |
| Framework repo | https://github.com/KanenasInGreece/Shared_Memory |
| Dashboard | http://127.0.0.1:8765/ (`/diagram`, `/logs`) |
| Gateway | http://localhost:8888 (user unit `hive-mind-gateway.service`) |

## On project open (first message)

When starting a **new conversation** in this project:

1. **Search shared memory** for prior monitor context:
   ```bash
   uv run --with httpx --with python-dotenv python ~/.grok/skills/shared-memory/scripts/memory_bridge.py search "shared memory monitor" 5
   ```
2. **Verify wiring** (no secrets printed):
   ```bash
   cd /home/xenofon/grok-labs/projects/shared-memory-monitor
   ./scripts/check-env.sh
   ```
3. **Check services**:
   ```bash
   systemctl --user is-active hive-mind-gateway.service shared-memory-monitor.service
   curl -sf http://127.0.0.1:8765/api/meta | head -c 200
   ```
4. Briefly report: token source (`monitor` vs `skill:*`), `compat=ok`, telemetry panels named by doctor
   (`nrem+breakdown+consolidation+entity_graph+latency+…`), LLM placement if present
   (`placement local` / `external`), both units active/inactive.

Skip the full greeting if the user already gave a concrete task.

## Filesystem boundary

**Code and docs writes** stay inside `/home/xenofon/grok-labs/projects/shared-memory-monitor/`.

**Allowed outside the repo (read/ops only):**
- `journalctl --user -u hive-mind-gateway.service` / `shared-memory-monitor.service`
- `systemctl --user` for monitor unit install/restart (after `./scripts/install-systemd-user.sh`)
- `curl` to `:8888` and `:8765`
- Reading framework docs at `SHARED_MEMORY_ROOT` if set in monitor `.env` (do not edit framework unless user asks)

**Never commit:** `.env`, `data/*`, `graphs/*`, `.grok/`, `.venv/`

## Secrets policy

- Monitor `.env` **wins** for `AGENT_TOKEN` and `COORDINATOR_URL` (see `env_loader.py`).
- Production token must be **dedicated monitor read-only** (`AGENT_ROLES=monitor:read` on gateway). Doctor should show `AGENT_TOKEN source: monitor`.
- `./scripts/pre-publish-check.sh` blocks pushes with real tokens or committed `.env`.
- Never print token values in chat or logs.

## Common workflows

### Develop and test

```bash
cd /home/xenofon/grok-labs/projects/shared-memory-monitor
uv sync
uv run pytest -q
./scripts/check-env.sh
./scripts/run-loop.sh --serve --interval 600   # foreground dev
```

### Restart persisted service (after code or .env change)

```bash
systemctl --user restart shared-memory-monitor.service
journalctl --user -u shared-memory-monitor.service -n 20 --no-pager
```

Re-run `./scripts/install-systemd-user.sh` if the checkout path moved.

### Backup status (Status sidebar, v0.4.6+)

- **Underway** — `GET /health` → `backup_in_progress` (gateway quiesce during `ops/backup.sh`).
- **Last** — `created` field from newest `sm-backup-*.manifest.json` under `BACKUP_DIR` (default `~/.shared-memory/backups`; override in monitor `.env` — never commit personal paths).
- **API** — `/api/health` → `backup: { in_progress, state, last_at, last_name, last_source }`.
- After `.env` or code changes: `systemctl --user restart shared-memory-monitor.service` (long-running process does not hot-reload).

### LLM pool + local/external placement (Status sidebar; framework ≥0.8.9)

- **Config hint** — `/health.config` summary via `/api/health` → `config.summary`
  (e.g. `2 LLM backends · local · embed 24k`).
- **Pool chips** — multi-backend `/health.llm_pool` joined to `config.llm_backends`
  for non-secret `has_credential` → UI `placement` `local`|`external` + optional `model`.
- **Doctor** — `./scripts/check-env.sh` → coordinator line includes `placement …`;
  JSON: `connectivity.coordinator.has_llm_placement`, `llm_local_count`, `llm_external_count`.
- **Never** put cloud LLM keys in monitor `.env` (gateway `token_env` only).

### Consolidation health (Status sidebar, v0.4.7+; per-type 24h activity ≥ framework 0.7.x)

- **Tile** — `GET /health` → `consolidation.{stalled,fresh,last_outcome,last_success_age_seconds,stalled_types,last_success_cycle_type}`; red when `stalled=true` and `fresh=true`; **signal stale** badge when `fresh=false`. Value names stalled types when present (`Stalled [fact consolidation]`).
- **Drill-down drawer** — `GET /api/consolidation` or click the sidebar card; per-cycle rows from `telemetry.consolidation` (insight + fact_consolidation): coverage (`eligible_clusters`), oldest wait, failures, `last_error`, plus **24h activity** (`runs_24h`, `cycle_seconds_avg`, `folds_succeeded_24h` / `folds_attempted_24h`). Liveness KPIs also show `stalled_types`, last success *(with cycle type)*, `last_active_cycle_type`.
- **Read per-cycle rows, not only the OR'd headline** — one type can fold while a sibling is stalled (framework decision 834 / fact 828).
- **Do not conflate** `telemetry.nrem` density cycles with `consolidation.*.backlog` (strict gate).
- **Logs** — Gateway tab: **Consolidation** filter chip; `/logs?source=gateway&consolidation=1`. Classify: `CRASHED` → error, `deferring` / `health refresh failed` → warn.
- Requires gateway ADR-018 (framework PR #79); `check-env --json` → `connectivity.telemetry.has_consolidation`.

### Publish to GitHub

```bash
cd /home/xenofon/grok-labs/projects/shared-memory-monitor
./scripts/publish.sh              # pre-publish-check + push origin main
```

Releases: tag must match `CHANGELOG.md`; use `gh release create vX.Y.Z --notes-file CHANGELOG.md`.

`gh` is logged in as **KanenasInGreece**; git uses **SSH** — do not switch origin to HTTPS.

## Architecture map (where to edit)

| Concern | Module / path |
|---------|----------------|
| Gateway HTTP client | `src/sm_telemetry_monitor/bridge.py` |
| Env precedence | `src/sm_telemetry_monitor/env_loader.py` |
| NREM cycle parsing | `src/sm_telemetry_monitor/nrem_backlog.py` |
| Schema panels (no PG) | `src/sm_telemetry_monitor/breakdown.py` |
| Doctor / check | `src/sm_telemetry_monitor/doctor.py`, `scripts/check-env.sh` |
| Gateway logs | `src/sm_telemetry_monitor/logs_reader.py` — `gateway` (journalctl), `rem_audit`, `agent_audit`, `credential_audit` (JSONL) |
| Poll cache | `collector.py`, `store.py` — append telemetry via `bridge.py` |
| Display helpers | `analytics.py`, `system_health.py` — format telemetry/health JSON |
| Consolidation panel | `src/sm_telemetry_monitor/consolidation.py` — ADR-018 liveness + coverage |
| Backup last-date reader | `src/sm_telemetry_monitor/backup_reader.py` — newest `sm-backup-*.manifest.json` in `BACKUP_DIR` |
| UI transport | `server.py`, `static/` — `/api/*` proxies bridge + logs_reader |
| systemd template | `deploy/systemd/user/shared-memory-monitor.service` |

**NREM backlog** = consolidation **cycles** from `telemetry.nrem`, not raw `facts_unconsolidated`. UI label "Breakdown unavailable" — not "Postgres unavailable".

## Gateway logs

Log sources on `/logs` (see `logs_reader.list_sources()`):

| Source | Kind | Path / command |
|--------|------|----------------|
| `gateway` | journal | `journalctl --user -u hive-mind-gateway.service` |
| `rem_audit` | jsonl | `AUDIT_LOG_PATH` → `rem-audit.jsonl` |
| `agent_audit` | jsonl | `GATEWAY_AUDIT_LOG_PATH` → `agent-audit.jsonl` (legacy `gateway-audit.jsonl`) |
| `credential_audit` | jsonl | `CREDENTIAL_AUDIT_LOG_PATH` → `credential-audit.jsonl` (framework ≥0.9.4; empty disables) |

`GATEWAY_AUDIT_LOG_PATH` must be whitelisted in `env_loader._FRAMEWORK_KEYS` and set on the gateway `.env` for lines to appear. Gateway audit tab supports per-agent filter chips in the UI.

```bash
journalctl --user -u hive-mind-gateway.service -f
tail -f ~/.shared-memory/logs/gateway-audit.jsonl
```

## When framework changes are needed

Gateway token roles, `telemetry.nrem`, `telemetry.breakdown` → change **framework repo**, not this one. Link sister relationship in `docs/SISTER_PROJECT.md`.

## After significant work

Save facts to shared memory:

```bash
uv run --with httpx --with python-dotenv python ~/.grok/skills/shared-memory/scripts/memory_bridge.py save "<what changed>" \
  '{"source":"grok","project":"shared-memory-monitor","domain":"shared-memory-monitor","entities":["SharedMemoryMonitor","Telemetry"]}'
```

## Reference

Detailed ops cheat sheet: [references/agent-ops.md](references/agent-ops.md)  
Human docs: `README.md`, `docs/GITHUB.md`, `docs/SISTER_PROJECT.md`