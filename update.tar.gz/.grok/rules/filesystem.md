# Filesystem — see workstation constitution

Boundary, secrets, and checkout path live in gitignored `CLAUDE.md`.
This file stays only so `.grok/rules/` still has a local pointer.
