# Local Antigravity entry (gitignored)

Do **not** duplicate the installer here.

| File | Role |
|------|------|
| [`AGENTS.md`](AGENTS.md) | Public installer — operate (Part 1) and develop commands (Part 2) |
| [`CLAUDE.md`](CLAUDE.md) | Workstation constitution (gitignored) — behaviour + shared-memory refs |
| [`README.md`](README.md) | Human product story |

Search shared memory (`--project shared-memory-monitor`) before reasoning on direction.

## Operating Principles & Cooperation

- **Session Framing (Fact 1252):** An agreed session frame (e.g., discussion vs. build) persists until the operator explicitly lifts it. Do not auto-switch frames based on input formatting.
- **Agent Tiering (Fact 523):** Enforce Single-Writer dominance. Sub-agents must submit proposals to `scratch/` rather than writing directly, allowing the primary agent to safely merge without concurrency deadlocks.

## Reviewing Plan & Protocols

- **4-Record Review Chain (Decision 1317 / Fact 1315):** All formal reviews must follow the strict chain: `Fact` -> `Decision` -> `Fix Fact` -> `Retrospective`. Reviews are permanently true about the commit they examine; never supersede them.
- **Build-Cycle Roles (Decision 1300):** For planned build cycles, we use the Fact 1184 subdivision: one agent plans/reviews/merges, while a separate builder subagent implements. We accept worktree and PR overhead for these cycles. The reviewer stays distinct from the merger.
- **Reviewer Roles (Fact 1319 / Decision 1300):** The 6 standard roles from `AGY_Role_Prompt.md` (Architecture, Code Quality, Security, Test, Ops, Adversarial) are **not** a standing session tax. They are reserved for release coverage (standard release = Architecture + Code Quality + Security). When used, each role writes to a fixed domain and uses exactly ONE entity (e.g., `GrokArchitectureReview`).
- **Dual-Track Review (Fact 1283):** Major plans undergo parallel, independent reviews against both the *plan* (intent) and the *current code* (reality) before building.
- **Persistence:** Review reports must be written to `Local_Documentation/Reviews/` in the main checkout.
