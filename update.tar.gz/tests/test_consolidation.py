import unittest
from datetime import UTC
from unittest.mock import patch

from sm_telemetry_monitor.consolidation import (
    consolidation_from_payload,
    consolidation_snapshot,
    humanize_age,
)


class HumanizeAgeTests(unittest.TestCase):
    def test_none(self):
        self.assertEqual(humanize_age(None), "—")

    def test_seconds(self):
        self.assertEqual(humanize_age(45), "45s ago")

    def test_minutes(self):
        self.assertEqual(humanize_age(125), "2m ago")


class ConsolidationFromPayloadTests(unittest.TestCase):
    def test_healthy_tile(self):
        health = {
            "status": "ok",
            "consolidation": {
                "stalled": False,
                "fresh": True,
                "last_outcome": "completed",
                "last_success_age_seconds": None,
            },
        }
        telemetry = {
            "status": "success",
            "telemetry": {
                "timestamp": "2026-06-25T10:00:00+00:00",
                "consolidation": {
                    "stall_threshold_seconds": 9000,
                    "insight": {
                        "last_outcome": "completed",
                        "in_flight": False,
                        "consecutive_failures": 0,
                        "backlog": 0,
                        "eligible_clusters": 0,
                        "stalled": False,
                    },
                    "fact_consolidation": {
                        "last_outcome": "completed",
                        "in_flight": False,
                        "consecutive_failures": 0,
                        "backlog": 0,
                        "stalled": False,
                    },
                },
                "nrem": {"fact_cycles": 0, "decision_cycles": 1},
            },
        }
        snap = consolidation_from_payload(health, telemetry, fetched_at="2026-06-25T10:01:00+00:00")
        self.assertTrue(snap["reachable"])
        self.assertEqual(snap["tile"]["value"], "Healthy")
        self.assertEqual(snap["tile"]["state"], "ok")
        self.assertFalse(snap["tile"]["stalled"])
        self.assertEqual(len(snap["cycles"]), 2)
        self.assertEqual(snap["cycles"][0]["label"], "Insight")

    def test_deferred_with_no_work_reads_idle(self):
        # A deferred cycle with an *explicit* empty gate census is idle, not a
        # postponed job, and must not be flagged as a warning.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "fact_consolidation": {
                        "last_outcome": "deferred",
                        "in_flight": False,
                        "consecutive_failures": 0,
                        "backlog": 0,
                        "eligible_clusters": 0,
                        "stalled": False,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertEqual(fact["last_outcome"], "deferred")
        self.assertEqual(fact["last_outcome_display"], "idle")
        self.assertEqual(fact["state"], "ok")

    def test_deferred_null_eligibility_keeps_deferred(self):
        # eligible_clusters=None means unknown (not "zero") — do not claim idle
        # while the cycle is still deferred for pool/GPU back-pressure.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "fact_consolidation": {
                        "last_outcome": "deferred",
                        "last_deferred_reason": "pool_busy",
                        "in_flight": False,
                        "consecutive_failures": 0,
                        "backlog": 0,
                        "eligible_clusters": None,
                        "stalled": False,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertEqual(fact["last_outcome_display"], "deferred — LLM pool busy")
        self.assertEqual(fact["state"], "ok")

    def test_deferred_with_backlog_stays_deferred(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "fact_consolidation": {
                        "last_outcome": "deferred",
                        "in_flight": False,
                        "consecutive_failures": 0,
                        "eligible_clusters": 3,
                        "stalled": False,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertEqual(fact["last_outcome_display"], "deferred")

    def test_deferred_reason_named(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True,
                                                    "last_outcome": "deferred"}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "inference_busy": "busy",
                "consolidation": {
                    "last_outcome": "deferred",
                    "last_deferred_reason": "gpu_busy",
                    "fact_consolidation": {
                        "last_outcome": "deferred",
                        "last_deferred_reason": "gpu_busy",
                        "in_flight": False,
                        "eligible_clusters": 3,
                        "stalled": False,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        self.assertEqual(snap["inference_busy"], "busy")
        self.assertEqual(snap["last_deferred_reason"], "gpu_busy")
        self.assertEqual(snap["last_deferred_reason_human"], "inference GPU busy")
        self.assertEqual(snap["tile"]["value"], "Deferred — inference GPU busy")
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertEqual(fact["last_outcome_display"], "deferred — inference GPU busy")
        self.assertEqual(fact["state"], "ok")

    def test_deferred_reason_pool_busy_named(self):
        # v0.6.1+ multi-backend gateways defer on a full LLM pool, not nvtop.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True,
                                                    "last_outcome": "deferred"}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "last_outcome": "deferred",
                    "last_deferred_reason": "pool_busy",
                    "fact_consolidation": {
                        "last_outcome": "deferred",
                        "last_deferred_reason": "pool_busy",
                        "in_flight": False,
                        "eligible_clusters": 3,
                        "stalled": False,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        self.assertEqual(snap["last_deferred_reason_human"], "LLM pool busy")
        self.assertEqual(snap["tile"]["value"], "Deferred — LLM pool busy")
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertEqual(fact["last_outcome_display"], "deferred — LLM pool busy")

    def test_stale_last_error_suppressed_after_completion(self):
        # The gateway keeps the most recent error forever (e.g. OrphanedRun from
        # a recovered daemon restart) — a completed cycle must not display it.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "fact_consolidation": {
                        "last_outcome": "completed",
                        "consecutive_failures": 0,
                        "stalled": False,
                        "last_error": {"class": "OrphanedRun",
                                       "msg": "daemon restarted while cycle was in-flight"},
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertIsNone(fact["last_error"])
        self.assertEqual(fact["state"], "ok")

    def test_current_last_error_still_surfaced(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "fact_consolidation": {
                        "last_outcome": "crashed",
                        "consecutive_failures": 2,
                        "stalled": False,
                        "last_error": {"class": "LLMTimeout", "msg": "timed out"},
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertEqual(fact["last_error"]["class"], "LLMTimeout")

    def test_fact_coverage_computed(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "neo4j": {
                    "facts_total": 175,
                    "facts_rem_pending": 0,
                    "facts_unconsolidated": 22,
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        cov = snap["coverage"]
        self.assertEqual(cov["rem_processed"], 175)
        self.assertEqual(cov["consolidated"], 153)
        self.assertEqual(cov["awaiting"], 22)
        self.assertEqual(cov["coverage_pct"], 87)
        self.assertEqual(cov["awaiting_pct"], 13)

    def test_fact_coverage_missing_census(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        snap = consolidation_from_payload(health, {"status": "success", "telemetry": {}})
        cov = snap["coverage"]
        self.assertIsNone(cov["rem_processed"])
        self.assertIsNone(cov["coverage_pct"])

    def test_graph_health_computed(self):
        # v0.6.1 entity_graph shape: orphans are degree-0 dangling, unmentioned
        # entities have edges but no live MENTIONS, alias layer is live.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "neo4j": {"facts_rem_pending": 50, "decisions_rem_pending": 32},
                "entity_graph": {
                    "entities_total": 2385,
                    "orphan_entities": 0,
                    "unmentioned_entities": 1384,
                    "singleton_entities": 538,
                    "alias_edges": 381,
                    "alias_covered_entities": 535,
                    "alias_components": 226,
                    "largest_alias_component": 9,
                    "top_hubs": [
                        {"name": "SharedMemory", "degree": 115},
                        {"name": "Neo4j", "degree": 112},
                    ],
                },
            },
        }
        gh = consolidation_from_payload(health, telemetry)["graph_health"]
        self.assertTrue(gh["present"])
        self.assertEqual(gh["entities_total"], 2385)
        self.assertIsNone(gh["genuinely_referenced_entities"])
        self.assertFalse(gh["alias_coverage_uses_genuine"])
        self.assertEqual(gh["orphan_entities"], 0)
        self.assertEqual(gh["orphan_pct"], 0)
        self.assertEqual(gh["unmentioned_entities"], 1384)
        self.assertEqual(gh["unmentioned_pct"], 58)
        self.assertEqual(gh["mentioned_entities"], 1001)
        self.assertEqual(gh["mentioned_pct"], 42)
        self.assertEqual(gh["singleton_pct"], 23)
        self.assertEqual(gh["alias_edges"], 381)
        self.assertEqual(gh["alias_components"], 226)
        self.assertEqual(gh["largest_alias_component"], 9)
        self.assertEqual(gh["alias_coverage_pct"], 22)
        self.assertEqual(gh["max_hub_degree"], 115)
        self.assertEqual(len(gh["top_hubs"]), 2)
        # REM-pending records inflate fragmentation counts → flagged so the share
        # reads as an upper bound, not a settled fragmentation verdict.
        self.assertTrue(gh["rem_pending"])
        self.assertEqual(gh["rem_pending_facts"], 50)
        self.assertEqual(gh["rem_pending_decisions"], 32)

    def test_graph_health_genuinely_referenced_alias_denominator(self):
        # Gateway ≥0.8.6 fact 895 (decision 890): alias coverage uses
        # genuinely_referenced, not the mixed entities_total population.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "entity_graph": {
                    "entities_total": 4141,
                    "genuinely_referenced_entities": 1885,
                    "orphan_entities": 0,
                    "unmentioned_entities": 2256,
                    "singleton_entities": 1193,
                    "alias_edges": 2323,
                    "alias_covered_entities": 1389,
                    "alias_components": 415,
                    "largest_alias_component": 76,
                    "top_hubs": [],
                },
            },
        }
        gh = consolidation_from_payload(health, telemetry)["graph_health"]
        self.assertEqual(gh["genuinely_referenced_entities"], 1885)
        self.assertEqual(gh["mentioned_entities"], 1885)
        self.assertTrue(gh["alias_coverage_uses_genuine"])
        # 1389/1885 ≈ 73.7% → round to 74 with _pct int rounding
        self.assertEqual(gh["alias_coverage_pct"], round(100 * 1389 / 1885))
        # Must not use entities_total (1389/4141 ≈ 33%)
        self.assertNotEqual(gh["alias_coverage_pct"], round(100 * 1389 / 4141))

    def test_graph_health_pre_061_gateway_degrades(self):
        # Gateways below 0.6.1 omit unmentioned_entities/alias_components — the
        # new KPIs degrade to None without blanking the rest.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "entity_graph": {"entities_total": 1736, "orphan_entities": 961,
                                 "singleton_entities": 416, "alias_edges": 0,
                                 "top_hubs": []},
            },
        }
        gh = consolidation_from_payload(health, telemetry)["graph_health"]
        self.assertTrue(gh["present"])
        self.assertEqual(gh["orphan_pct"], 55)
        self.assertIsNone(gh["unmentioned_entities"])
        self.assertIsNone(gh["mentioned_entities"])
        self.assertIsNone(gh["alias_components"])
        self.assertEqual(gh["singleton_pct"], 24)

    def test_graph_health_no_rem_pending(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "neo4j": {"facts_rem_pending": 0, "decisions_rem_pending": 0},
                "entity_graph": {"entities_total": 100, "orphan_entities": 10,
                                 "singleton_entities": 5, "top_hubs": []},
            },
        }
        gh = consolidation_from_payload(health, telemetry)["graph_health"]
        self.assertTrue(gh["present"])
        self.assertFalse(gh["rem_pending"])

    def test_graph_health_missing(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        gh = consolidation_from_payload(health, {"status": "success", "telemetry": {}})["graph_health"]
        self.assertFalse(gh["present"])
        self.assertIsNone(gh["orphan_pct"])
        self.assertEqual(gh["top_hubs"], [])

    def test_first_write_quality_computed(self):
        # telemetry.spine (gateway v0.6.2+) + postgres dead-letter age → the
        # upstream first-write-quality band.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "postgres": {"outbox_failed_oldest_age_seconds": None},
                "spine": {
                    "decisions": {"total": 190, "grounded_in_pct": 4.2,
                                  "alternatives_pct": 76.3, "confidence_pct": 83.7,
                                  "elicited_pct": 2.1},
                    "facts": {"total": 285, "source_ref_pct": 6.7, "elicited_pct": 0.7},
                    "retrospectives": {"total": 150, "rating_pct": 100.0, "target_pg_id_pct": 100.0, "grounded_in_pct": 18.0, "elicited_pct": 15.0},
                    "emergent_unprojected_fields": [
                        {"key": "connected_from", "n": 193},
                        {"key": "principal", "n": 193},
                    ],
                    "alias": {"adjudications": 612, "by_verdict": {"alias": 381, "distinct": 231}},
                },
            },
        }
        q = consolidation_from_payload(health, telemetry)["first_write_quality"]
        self.assertTrue(q["present"])
        self.assertEqual(q["decisions"]["grounded_in_pct"], 4.2)
        self.assertEqual(q["facts"]["source_ref_pct"], 6.7)
        self.assertEqual(q["retrospectives"]["rating_pct"], 100.0)
        self.assertEqual(q["retrospectives"]["total"], 150)
        self.assertEqual(q["emergent_count"], 2)
        self.assertEqual(q["alias_merged"], 381)
        self.assertEqual(q["alias_distinct"], 231)
        self.assertIsNone(q["dead_letter_age_seconds"])   # healthy: nothing stuck
        self.assertIsNone(q["dead_letter_age_human"])
        # gateway <0.8.40: alternative_vectors omitted → present=False
        self.assertFalse(q["alternative_vectors"]["present"])

    def test_first_write_quality_alternative_vectors(self):
        # Framework 0.8.40 / decisions 1024+1027: failing+aged pending → not just numbers.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "spine": {
                    "decisions": {"total": 262, "alternatives_pct": 82.8},
                    "alternative_vectors": {
                        "entries": 450,
                        "decisions": 219,
                        "embedded": 440,
                        "pending": 8,
                        "failing": 2,
                        "embedded_pct": 97.8,
                        "oldest_pending_age_s": 3600,
                    },
                },
            },
        }
        q = consolidation_from_payload(health, telemetry)["first_write_quality"]
        av = q["alternative_vectors"]
        self.assertTrue(av["present"])
        self.assertEqual(av["entries"], 450)
        self.assertEqual(av["decisions"], 219)
        self.assertEqual(av["embedded"], 440)
        self.assertEqual(av["pending"], 8)
        self.assertEqual(av["failing"], 2)
        self.assertEqual(av["embedded_pct"], 97.8)
        self.assertEqual(av["oldest_pending_age_s"], 3600)
        self.assertEqual(av["oldest_pending_age_human"], "1h ago")
        self.assertEqual(av["state"], "failing")
        self.assertIn("considered", (av["purpose"] or "").lower())
        self.assertIn("failing", (av["caption"] or "").lower())
        self.assertEqual(av["recorded_alternatives_pct"], 82.8)
        self.assertEqual(av["decisions_total"], 262)
        self.assertIn("recorded", (av["caption"] or "").lower())

    def test_first_write_quality_alternative_vectors_healthy(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "spine": {
                    "decisions": {"total": 262, "alternatives_pct": 82.8},
                    "alternative_vectors": {
                        "entries": 450,
                        "decisions": 219,
                        "embedded": 450,
                        "pending": 0,
                        "failing": 0,
                        "embedded_pct": 100.0,
                        "oldest_pending_age_s": None,
                    },
                },
            },
        }
        av = consolidation_from_payload(health, telemetry)["first_write_quality"][
            "alternative_vectors"
        ]
        self.assertTrue(av["present"])
        self.assertEqual(av["pending"], 0)
        self.assertEqual(av["failing"], 0)
        self.assertIsNone(av["oldest_pending_age_s"])
        self.assertIsNone(av["oldest_pending_age_human"])
        self.assertEqual(av["state"], "searchable")
        self.assertIn("searchable", (av["caption"] or "").lower())
        self.assertIn("caught up", (av["caption"] or "").lower())
        # Dual instrument: recording rate is named so UI is not a bare count.
        self.assertIn("82.8", av["caption"] or "")
        self.assertIn("recorded", (av["caption"] or "").lower())

    def test_first_write_quality_alternative_vectors_stalled_populator(self):
        # High recording rate + aged pending → populator story, not elicitation.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "spine": {
                    "decisions": {"total": 100, "alternatives_pct": 90.0},
                    "alternative_vectors": {
                        "entries": 200,
                        "decisions": 90,
                        "embedded": 150,
                        "pending": 50,
                        "failing": 0,
                        "embedded_pct": 75.0,
                        "oldest_pending_age_s": 3600,
                    },
                },
            },
        }
        av = consolidation_from_payload(health, telemetry)["first_write_quality"][
            "alternative_vectors"
        ]
        self.assertEqual(av["state"], "stalled_populator")
        self.assertIn("populator", (av["caption"] or "").lower())
        self.assertIn("recording is healthy", (av["caption"] or "").lower())

    def test_first_write_quality_dead_letter_age(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "postgres": {"outbox_failed_oldest_age_seconds": 7200},
                "spine": {"facts": {"total": 10, "source_ref_pct": 50.0}},
            },
        }
        q = consolidation_from_payload(health, telemetry)["first_write_quality"]
        self.assertEqual(q["dead_letter_age_seconds"], 7200)
        self.assertEqual(q["dead_letter_age_human"], "2h ago")

    def test_first_write_quality_missing_on_old_gateway(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        q = consolidation_from_payload(health, {"status": "success", "telemetry": {}})["first_write_quality"]
        self.assertFalse(q["present"])
        self.assertEqual(q["emergent_fields"], [])
        self.assertFalse(q["alternative_vectors"]["present"])

    def test_schema_conformance_non_compliant(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "compliance": {
                    "predicate_distribution": {"MENTIONS": 4458, "GROUNDED_IN": 13},
                    "label_compliance": "non-compliant",
                    "relationship_compliance": "non-compliant",
                    "invalid_labels": [{"name": "Conversation", "count": 5},
                                       {"name": "DockerContainer", "count": 4}],
                    "invalid_relationships": [{"name": "HAS_STEP", "count": 4}],
                },
            },
        }
        c = consolidation_from_payload(health, telemetry)["schema_conformance"]
        self.assertTrue(c["present"])
        self.assertFalse(c["compliant"])
        self.assertEqual(c["invalid_label_total"], 9)
        self.assertEqual(c["invalid_relationship_total"], 4)
        self.assertEqual(c["predicate_types"], 2)

    def test_schema_conformance_missing_on_old_gateway(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        c = consolidation_from_payload(health, {"status": "success", "telemetry": {}})["schema_conformance"]
        self.assertFalse(c["present"])
        self.assertFalse(c["compliant"])
        self.assertEqual(c["invalid_labels"], [])

    def test_last_success_falls_back_to_freshest_cycle(self):
        # Top-level rollup age is null but a cycle succeeded — use the cycle age.
        health = {
            "status": "ok",
            "consolidation": {"stalled": False, "fresh": True, "last_outcome": "completed",
                              "last_success_age_seconds": None},
        }
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "insight": {"last_outcome": "completed", "last_success_age_seconds": None,
                                "eligible_clusters": 0, "stalled": False},
                    "fact_consolidation": {"last_outcome": "completed", "last_success_age_seconds": 16255,
                                           "eligible_clusters": 0, "stalled": False},
                },
            },
        }
        tile = consolidation_from_payload(health, telemetry)["tile"]
        self.assertEqual(tile["last_success_age_seconds"], 16255)
        self.assertTrue(tile["last_success_age_human"])

    def test_last_success_omitted_when_unknown(self):
        health = {
            "status": "ok",
            "consolidation": {"stalled": False, "fresh": True, "last_outcome": "completed",
                              "last_success_age_seconds": None},
        }
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "insight": {"last_outcome": "completed", "last_success_age_seconds": None, "stalled": False},
                    "fact_consolidation": {"last_outcome": "deferred", "last_success_age_seconds": None, "stalled": False},
                },
            },
        }
        tile = consolidation_from_payload(health, telemetry)["tile"]
        self.assertIsNone(tile["last_success_age_seconds"])
        self.assertIsNone(tile["last_success_age_human"])

    def test_coverage_decisions_and_summaries(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "neo4j": {"facts_total": 175, "facts_rem_pending": 0, "facts_unconsolidated": 22,
                          "decisions_total": 119, "decisions_rem_pending": 0},
                "breakdown": {"summaries": [
                    {"kind": "insight", "active": 13, "superseded": 0},
                    {"kind": "thematic", "active": 7, "superseded": 1},
                ]},
            },
        }
        cov = consolidation_from_payload(health, telemetry)["coverage"]
        self.assertEqual(cov["decisions_total"], 119)
        self.assertEqual(cov["decisions_rem_processed"], 119)
        self.assertEqual(len(cov["summaries"]), 2)
        self.assertEqual(cov["summaries_active"], 20)
        self.assertEqual(cov["summaries_superseded"], 1)

    def test_stalled_tile(self):
        health = {
            "status": "ok",
            "consolidation": {
                "stalled": True,
                "fresh": True,
                "last_outcome": "deferred",
            },
        }
        snap = consolidation_from_payload(health, {"status": "success", "telemetry": {}})
        self.assertEqual(snap["tile"]["state"], "bad")
        self.assertEqual(snap["tile"]["value"], "Stalled")

    def test_per_cycle_type_telemetry(self):
        # Framework decision 834 / fact 835: OR'd stall + per-type 24h activity.
        # Headline must name which type is stalled and which produced last success.
        health = {
            "status": "ok",
            "consolidation": {
                "stalled": True,
                "fresh": True,
                "last_outcome": "completed",
                "last_success_age_seconds": 15451,
                "last_success_cycle_type": "fact_consolidation",
                "stalled_types": ["fact_consolidation"],
            },
        }
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "stall_threshold_seconds": 9000,
                    "stalled": True,
                    "stalled_types": ["fact_consolidation"],
                    "last_success_age_seconds": 15451,
                    "last_success_cycle_type": "fact_consolidation",
                    "last_outcome": "completed",
                    "last_active_cycle_type": "fact_consolidation",
                    "insight": {
                        "last_outcome": "completed",
                        "last_success_age_seconds": 459554,
                        "stalled": False,
                        "eligible_clusters": 0,
                        "runs_24h": 16,
                        "cycle_seconds_avg": 0.1,
                        "folds_succeeded_24h": 0,
                        "folds_attempted_24h": 0,
                    },
                    "fact_consolidation": {
                        "last_outcome": "completed",
                        "last_success_age_seconds": 15451,
                        "stalled": True,
                        "backlog": 5,
                        "runs_24h": 39,
                        "cycle_seconds_avg": 192.4,
                        "folds_succeeded_24h": 17,
                        "folds_attempted_24h": 69,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        tile = snap["tile"]
        self.assertEqual(tile["state"], "bad")
        self.assertEqual(tile["value"], "Stalled [fact consolidation]")
        self.assertEqual(tile["stalled_types"], ["fact_consolidation"])
        self.assertEqual(tile["last_success_cycle_type"], "fact_consolidation")
        self.assertEqual(tile["last_active_cycle_type"], "fact_consolidation")
        self.assertIn("fact consolidation", tile["caption"])
        self.assertIn("success", tile["caption"])

        insight = next(c for c in snap["cycles"] if c["key"] == "insight")
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        self.assertEqual(insight["runs_24h"], 16)
        self.assertEqual(insight["cycle_seconds_avg"], 0.1)
        self.assertEqual(insight["cycle_seconds_avg_human"], "0.1s")
        self.assertEqual(insight["folds_24h_display"], "0/0")
        self.assertFalse(insight["stalled"])
        self.assertEqual(fact["runs_24h"], 39)
        self.assertEqual(fact["cycle_seconds_avg_human"], "3.2m")
        self.assertEqual(fact["folds_24h_display"], "17/69")
        self.assertTrue(fact["stalled"])
        self.assertEqual(snap["rollup"]["stalled_types_short"], ["fact consolidation"])
        self.assertTrue(snap["activity_note"])

    def test_stalled_types_derived_from_cycles_when_missing(self):
        # Older gateways may OR stall without stalled_types — derive from cycles.
        health = {
            "status": "ok",
            "consolidation": {"stalled": True, "fresh": True, "last_outcome": "completed"},
        }
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "stalled": True,
                    "insight": {"stalled": False, "last_outcome": "completed"},
                    "fact_consolidation": {"stalled": True, "last_outcome": "completed"},
                },
            },
        }
        tile = consolidation_from_payload(health, telemetry)["tile"]
        self.assertEqual(tile["stalled_types"], ["fact_consolidation"])
        self.assertEqual(tile["value"], "Stalled [fact consolidation]")

    def test_cycle_activity_missing_on_old_gateway(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "insight": {"last_outcome": "completed", "stalled": False},
                },
            },
        }
        insight = consolidation_from_payload(health, telemetry)["cycles"][0]
        self.assertIsNone(insight["runs_24h"])
        self.assertIsNone(insight["cycle_seconds_avg"])
        self.assertIsNone(insight["folds_24h_display"])

    def test_idle_deferred_24h_surfaced(self):
        # Decision 842 (provisional): per-consumer idle clock split. Verify the
        # cycle carries deferred/idle counts and the provisional note is present.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "fact_consolidation": {
                        "last_outcome": "completed",
                        "stalled": False,
                        "runs_24h": 41,
                        "deferred_24h": 0,
                        "idle_24h": 0,
                    },
                    "insight": {
                        "last_outcome": "crashed",
                        "stalled": False,
                        "runs_24h": 10,
                        "deferred_24h": 7,
                        "idle_24h": 2,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        fact = next(c for c in snap["cycles"] if c["key"] == "fact_consolidation")
        insight = next(c for c in snap["cycles"] if c["key"] == "insight")
        self.assertEqual(fact["deferred_24h"], 0)
        self.assertEqual(fact["idle_24h"], 0)
        self.assertEqual(fact["idle_deferred_24h_display"], "0/0")
        self.assertEqual(insight["deferred_24h"], 7)
        self.assertEqual(insight["idle_24h"], 2)
        self.assertEqual(insight["idle_deferred_24h_display"], "7/2")
        self.assertIn("842", snap["idle_deferred_note"])

    def test_idle_deferred_24h_missing_on_old_gateway(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {"insight": {"last_outcome": "completed", "stalled": False}},
            },
        }
        insight = consolidation_from_payload(health, telemetry)["cycles"][0]
        self.assertIsNone(insight["deferred_24h"])
        self.assertIsNone(insight["idle_24h"])
        self.assertIsNone(insight["idle_deferred_24h_display"])

    def test_rem_reliability_computed(self):
        # Decision 819: rem_attempts split into rem_pickups/rem_attempts; the
        # gateway now reports the previously-invisible stranded-record signal.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "neo4j": {"rem_dead_lettered": 0, "rem_failing": 5, "rem_max_attempts": 5},
            },
        }
        rr = consolidation_from_payload(health, telemetry)["rem_reliability"]
        self.assertTrue(rr["present"])
        self.assertEqual(rr["dead_lettered"], 0)
        self.assertEqual(rr["failing"], 5)
        self.assertEqual(rr["max_attempts"], 5)
        self.assertIsNone(rr["passed_over_total"])
        self.assertIsNone(rr["starved_pending"])

    def test_rem_reliability_fairness_086(self):
        # Fact 895 / decision 894 / gateway 0.8.6: batch-vs-solo fairness gauges.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "neo4j": {
                    "rem_dead_lettered": 0,
                    "rem_failing": 0,
                    "rem_max_attempts": 5,
                    "rem_passed_over_total": 12,
                    "rem_starved_pending": 2,
                },
            },
        }
        rr = consolidation_from_payload(health, telemetry)["rem_reliability"]
        self.assertTrue(rr["present"])
        self.assertEqual(rr["passed_over_total"], 12)
        self.assertEqual(rr["starved_pending"], 2)

    def test_rem_reliability_missing_on_old_gateway(self):
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        rr = consolidation_from_payload(health, {"status": "success", "telemetry": {}})["rem_reliability"]
        self.assertFalse(rr["present"])
        self.assertIsNone(rr["dead_lettered"])
        self.assertIsNone(rr["passed_over_total"])

    def test_in_flight_reports_running_duration(self):
        # last_started only means "still running" while in_flight — surface how
        # long, rather than a flat yes/no (gateway carries this but the monitor
        # never read it).
        from datetime import datetime, timedelta

        started = (datetime.now(UTC) - timedelta(minutes=3, seconds=5)).isoformat()
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "insight": {
                        "last_outcome": "completed",
                        "in_flight": True,
                        "last_started": started,
                        "consecutive_failures": 0,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        cycle = next(c for c in snap["cycles"] if c["key"] == "insight")
        self.assertTrue(cycle["in_flight"])
        self.assertIsNotNone(cycle["running_seconds"])
        self.assertGreater(cycle["running_seconds"], 180)
        self.assertEqual(cycle["running_human"], "3.1m")

    def test_last_started_ignored_when_not_in_flight(self):
        # A completed cycle's last_started is the *previous* run — must not be
        # read as "still running".
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "consolidation": {
                    "insight": {
                        "last_outcome": "completed",
                        "in_flight": False,
                        "last_started": "2026-01-01T00:00:00+00:00",
                        "consecutive_failures": 0,
                    },
                },
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        cycle = next(c for c in snap["cycles"] if c["key"] == "insight")
        self.assertIsNone(cycle["running_seconds"])
        self.assertIsNone(cycle["running_human"])

    def test_nrem_density_thresholds_pass_through(self):
        # Live gate thresholds (telemetry.nrem.fact_threshold/decision_threshold)
        # flow to the frontend note instead of only being assumed client-side.
        health = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        telemetry = {
            "status": "success",
            "telemetry": {
                "nrem": {"fact_cycles": 3, "decision_cycles": 1, "fact_threshold": 5, "decision_threshold": 2},
            },
        }
        snap = consolidation_from_payload(health, telemetry)
        self.assertEqual(snap["nrem_density"]["fact_threshold"], 5)
        self.assertEqual(snap["nrem_density"]["decision_threshold"], 2)

    def test_stale_signal(self):
        health = {
            "status": "ok",
            "consolidation": {"stalled": True, "fresh": False},
        }
        snap = consolidation_from_payload(health, {"status": "success", "telemetry": {}})
        self.assertEqual(snap["tile"]["state"], "warn")
        self.assertEqual(snap["tile"]["value"], "Signal stale")

    @patch("sm_telemetry_monitor.consolidation.get_telemetry")
    @patch("sm_telemetry_monitor.consolidation.get_health")
    def test_snapshot_calls_bridge(self, mock_health, mock_telemetry):
        mock_health.return_value = {"status": "ok", "consolidation": {"stalled": False, "fresh": True}}
        mock_telemetry.return_value = {"status": "success", "telemetry": {}}
        snap = consolidation_snapshot()
        self.assertTrue(snap["reachable"])
        mock_health.assert_called_once()
        mock_telemetry.assert_called_once()


if __name__ == "__main__":
    unittest.main()