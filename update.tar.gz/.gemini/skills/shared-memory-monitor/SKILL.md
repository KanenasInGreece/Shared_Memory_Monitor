---
name: shared-memory-monitor
description: Maintainer instructions for the Shared Memory Monitor repository
---

# Shared Memory Monitor Development Skill

When working inside the Shared Memory Monitor repository, you must adhere to the following workflow and rules:

1. **Check Environment First**: Always run `./scripts/agent-status.sh` or `./scripts/check-env.sh` before making changes to understand the current state.
2. **Read the Constitution**: The primary repository constraints and invariants are detailed in `GEMINI.md` at the root of the project. You must follow the boundaries described there.
3. **No Direct Databases**: You must never try to directly connect to Postgres or Neo4j in this project. All data must be sourced via the Coordinator HTTP endpoints defined in `src/sm_telemetry_monitor/bridge.py`.
4. **Testing & Execution**: Run tests using `uv run --with pytest python -m pytest -q`. Crucially, **execute tests against the running live local gateway** instead of mocking external dependencies. Since we are using the monitor to observe a running Shared Memory framework (also developed locally), verifying against the live `:8888` endpoints ensures realistic architectural and concurrency validation.
5. **Polyphony & Architecture Verification**: As governed by the global `Oratotis-Workstation-Global` rules, verify that the telemetry polling loops do not block each other and that HTTP clients run efficiently.
6. **No Secrets**: Never commit or expose `AGENT_TOKEN` or other credentials. Ensure `.env` is gitignored.

Always verify your changes by running the local server (`./scripts/run-loop.sh --serve`) and checking the output.
