# Shared Memory Monitor — workstation constitution

**Not shipped.** The public installer (operate + develop commands) is [`AGENTS.md`](AGENTS.md). The human product story is [`README.md`](README.md). This file is local agent behaviour only.

Search shared memory first (`--project shared-memory-monitor`). When a row below matches the task, **fetch that ref** (`lineage` / `search`) instead of inventing or restating it here. Titles are enough to decide whether to fetch.

<!-- shared-memory:constitution-snippet v2 -->
## Shared Memory
Use the shared memory skill proactively — to draw from it, not only save to
it. Locally preloaded per-project notes are supplementary scratch space, not
authoritative: for any question about project direction, a prior decision, or
a claim that may have been superseded, the shared memory store is the source
of truth, and searching it is a precondition before reasoning on that topic —
not a judgment call to make first. After a discussion that sets project
direction, propose recording the key facts, and confirm with the user before
saving any decision — never auto-decide (facts can later be superseded;
decision outcomes get recorded afterward as retrospectives).
<!-- /shared-memory:constitution-snippet -->

## This checkout

- Root: `/home/xenofon/grok-labs/projects/shared-memory-monitor`
- Dashboard `:8765` · gateway `:8888` · token source must be **monitor**
- Code/docs writes stay in this tree. Outside: `systemctl` / `journalctl` / `curl` only.
- Never commit `.env`, `data/`, `graphs/`. Never echo `AGENT_TOKEN`.

## Direction — fetch when the title applies

### Product (what may appear on screen)

| Title | Ref |
|-------|-----|
| All on-screen data from `bridge.py` or `logs_reader.py` only | `fact:317` |
| Dedicated `monitor:read` token — monitor `.env` wins | `decision:257` |
| Standalone gateway client — telemetry + breakdown, zero Postgres | `decision:260` |
| Telemetry surfaces signal; logs carry the detail | `decision:1295` |
| A3 surface as deployed (llm_faults, credentials, credential-audit.jsonl) | `fact:1297` |
| Monitor contract — what to report vs what to view in the logs | `fact:365` |

### Process (how to change this repo)

| Title | Ref |
|-------|-----|
| Adopt 1184 here: Grok 4.6 plans/assigns/reviews/merges; Grok Build builds | `decision:1300` |
| Build-cycle formalisation (file ownership, worktrees, reviewer ≠ merger) | `fact:1184` |
| Cooperation principles (outcome before mechanism; reviewers find, operator rules) | `fact:1085` |
| Six-role review framework (optional at release, not every session) | `fact:1200` |
| Gitignore workstation maintainer docs | `decision:304` |
| agent_audit + archive picker; no `save_logs` tab | `decision:303` · `decision:302` |

Framework-side identity/telemetry (read when changing the wire): `decision:254` · `decision:256` · `decision:258`.

## Session split

| User asked to… | Follow |
|----------------|--------|
| Install / status / start / upgrade | `AGENTS.md` Part 1 |
| Change code, UI, or docs | `AGENTS.md` Part 2 commands + this file + fetched refs |
| Understand the product | `README.md` |

Do not copy installer playbooks into this file. Do not copy hive-mind records into this file.
