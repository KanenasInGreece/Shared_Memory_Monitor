#!/usr/bin/env bash
# Install shared-memory-monitor as a systemd user service (survives logout with linger).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
UNIT_SRC="$ROOT/deploy/systemd/user/shared-memory-monitor.service"
UNIT_DST="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user/shared-memory-monitor.service"

if [[ ! -f "$UNIT_SRC" ]]; then
  echo "Missing unit file: $UNIT_SRC" >&2
  exit 1
fi

mkdir -p "$(dirname "$UNIT_DST")"
sed "s|@MONITOR_ROOT@|$ROOT|g" "$UNIT_SRC" > "$UNIT_DST"
echo "Installed → $UNIT_DST (MONITOR_ROOT=$ROOT)"

systemctl --user daemon-reload
systemctl --user enable shared-memory-monitor.service

echo ""
echo "Ensuring user service survives logout (linger)..."
if loginctl enable-linger "$USER" 2>/dev/null; then
  echo "Linger enabled."
elif sudo -n loginctl enable-linger "$USER" 2>/dev/null; then
  echo "Linger enabled (via sudo -n)."
else
  echo "WARNING: Could not enable linger."
  echo "  Without linger, the monitor will die when you log out."
  echo "  Please run this manually: sudo loginctl enable-linger "$USER""
fi


if command -v ss >/dev/null 2>&1 && ss -tln 2>/dev/null | grep -q ':8765 '; then
  echo ""
  echo "Port 8765 in use — stopping foreground listener, then starting user unit..."
  if command -v fuser >/dev/null 2>&1; then
    fuser -k 8765/tcp 2>/dev/null || true
  else
    echo "fuser not found. Please manually kill the process on port 8765 if the restart fails."
  fi
  sleep 0.5
fi

systemctl --user restart shared-memory-monitor.service
systemctl --user --no-pager status shared-memory-monitor.service
echo ""
echo "Dashboard → http://127.0.0.1:8765/  (/diagram, /logs)"
echo "Status:    ./scripts/agent-status.sh"
echo "Doctor:    ./scripts/check-env.sh   # gateway version · API compat · telemetry panels · LLM placement"
echo ""
echo "On Status (/): Infrastructure shows Gateway version · API · N LLM backends · local|external;"
echo "multi-backend gateways also show the LLM pool chips (local/external badges when gateway ≥0.8.9)."